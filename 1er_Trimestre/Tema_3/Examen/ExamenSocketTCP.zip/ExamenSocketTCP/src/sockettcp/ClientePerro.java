package sockettcp;


public class ClientePerro {

    public static void main(String[] artgs) {
        
     
        
    }
                      
}