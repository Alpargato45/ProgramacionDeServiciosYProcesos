package ejercicioareatriangulo;



public class EjercicioAreaTriangulo {

    
    public static void main(String[] args) {
        
        Triangulo t1 = new Triangulo(2,5);
        Triangulo t2 = new Triangulo(6,5);
        Triangulo t3 = new Triangulo(2,2);
        Triangulo t4 = new Triangulo(7,1);
        Triangulo t5 = new Triangulo(9,8);
        Triangulo t6 = new Triangulo(1,5);
        Triangulo t7 = new Triangulo(0,5);
        Triangulo t8 = new Triangulo(6,6);
        Triangulo t9 = new Triangulo(9,1);
        Triangulo t10 = new Triangulo(4,8);
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();
        t8.start();
        t9.start();
        t10.start();
    }
    
}
