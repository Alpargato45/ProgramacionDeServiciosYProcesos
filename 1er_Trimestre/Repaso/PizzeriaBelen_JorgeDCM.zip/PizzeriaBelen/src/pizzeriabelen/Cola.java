package pizzeriabelen;

import java.util.*;
import pizzas.Pizza;

public class Cola implements AccionesEstructuras<Pizza> {

    private Pizza[] colaHorno;

    public Cola() {
        this.colaHorno = new Pizza[10];
    }

    @Override
    public boolean push(Pizza elemento) {
        for (int i = 0; i < colaHorno.length; i++) {
            if (colaHorno[i] == null) {
                colaHorno[i] = (Pizza) elemento;
                return true;
            }
        }
        return false;
    }

    @Override
    public Pizza pop() {
        Pizza o1 = colaHorno[0];
        int numElementos = getNumElementos();
        for (int i = 0; i < numElementos; i++) {
            colaHorno[i] = colaHorno[i + 1];
            colaHorno[i + 1] = null;
        }
        return o1;
    }

    @Override
    public boolean esVacia() {
        if (colaHorno[0] == null) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int getNumElementos() {
        int num = colaHorno.length;
        for (int i = 0; i < colaHorno.length; i++) {
            if (colaHorno[i] == null) {
                num = i;
                return num;
            }
        }
        return num;
    }

}
