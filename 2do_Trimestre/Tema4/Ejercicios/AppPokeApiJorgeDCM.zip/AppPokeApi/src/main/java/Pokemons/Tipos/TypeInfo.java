package Pokemons.Tipos;

/**
 *
 * @author Jorge del Cid Moreno
 */
public class TypeInfo {
    
    private String name;

    public TypeInfo(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
